/*	sleep.h
	Best viewed with tabs set to 4 spaces.
*/

#ifndef SLEEP_H
	#include	"kernel.h"

//	Prototypes
	void	msleep(uint32_t msecs);
#endif
